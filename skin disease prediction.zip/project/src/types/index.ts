export interface Disease {
  name: string;
  confidence: number;
  description: string;
  symptoms: string[];
}

export interface PredictionResult {
  diseases: Disease[];
  timestamp: string;
}

export interface ImageFile extends File {
  preview: string;
}