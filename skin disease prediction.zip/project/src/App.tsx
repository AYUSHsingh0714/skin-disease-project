import React, { useState } from 'react';
import { Header } from './components/Header';
import { ImageUploader } from './components/ImageUploader';
import { PredictionResults } from './components/PredictionResults';
import type { Disease, ImageFile } from './types';

function App() {
  const [selectedImage, setSelectedImage] = useState<ImageFile | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState<Disease[] | null>(null);

  const handleImageSelect = (file: File) => {
    const imageFile = Object.assign(file, {
      preview: URL.createObjectURL(file)
    }) as ImageFile;
    
    setSelectedImage(imageFile);
    setIsAnalyzing(true);
    
    // Simulate API call with mock data
    setTimeout(() => {
      setResults([
        {
          name: 'Eczema',
          confidence: 85,
          description: 'A condition that causes the skin to become itchy, red, dry and cracked.',
          symptoms: ['Dry skin', 'Itching', 'Red and inflamed skin', 'Rough, scaly patches']
        },
        {
          name: 'Psoriasis',
          confidence: 12,
          description: 'A condition causing red, flaky, crusty patches of skin covered with silvery scales.',
          symptoms: ['Red patches', 'Silvery scales', 'Dry, cracked skin', 'Itching or burning']
        }
      ]);
      setIsAnalyzing(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-semibold mb-4">Upload Image</h2>
              <ImageUploader onImageSelect={handleImageSelect} />
            </div>
            
            {selectedImage && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-xl font-semibold mb-4">Selected Image</h2>
                <img
                  src={selectedImage.preview}
                  alt="Selected skin condition"
                  className="w-full h-64 object-cover rounded-lg"
                />
              </div>
            )}
          </div>

          <div>
            {isAnalyzing ? (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex flex-col items-center justify-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mb-4"></div>
                  <p className="text-gray-600">Analyzing image...</p>
                </div>
              </div>
            ) : results ? (
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Analysis Results</h2>
                <PredictionResults diseases={results} />
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex flex-col items-center justify-center h-64 text-gray-500">
                  <p>Upload an image to see the analysis results</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;