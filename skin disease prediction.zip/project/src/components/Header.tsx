import React from 'react';
import { Stethoscope } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center">
          <Stethoscope className="h-8 w-8 text-blue-600" />
          <div className="ml-3">
            <h1 className="text-2xl font-bold text-gray-900">
              Skin Disease Predictor
            </h1>
            <p className="text-sm text-gray-500">
              AI-powered skin condition analysis
            </p>
          </div>
        </div>
      </div>
    </header>
  );
};