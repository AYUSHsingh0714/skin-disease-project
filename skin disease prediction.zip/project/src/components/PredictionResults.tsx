import React from 'react';
import { AlertCircle } from 'lucide-react';
import type { Disease } from '../types';

interface PredictionResultsProps {
  diseases: Disease[];
}

export const PredictionResults: React.FC<PredictionResultsProps> = ({ diseases }) => {
  return (
    <div className="space-y-4">
      {diseases.map((disease, index) => (
        <div
          key={disease.name}
          className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-semibold text-gray-800">{disease.name}</h3>
            <div className="flex items-center">
              <div className="w-24 h-2 bg-gray-200 rounded-full mr-3">
                <div
                  className="h-full bg-blue-600 rounded-full"
                  style={{ width: `${disease.confidence}%` }}
                />
              </div>
              <span className="text-sm font-medium text-gray-600">
                {disease.confidence}%
              </span>
            </div>
          </div>
          
          <p className="text-gray-600 mb-4">{disease.description}</p>
          
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-gray-700 flex items-center">
              <AlertCircle className="w-4 h-4 mr-2 text-amber-500" />
              Common Symptoms
            </h4>
            <ul className="list-disc list-inside text-sm text-gray-600 pl-4">
              {disease.symptoms.map((symptom, idx) => (
                <li key={idx}>{symptom}</li>
              ))}
            </ul>
          </div>
        </div>
      ))}
    </div>
  );
};